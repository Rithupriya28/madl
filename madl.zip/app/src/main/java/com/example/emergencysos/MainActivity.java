package com.example.emergencysos;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends android.app.Activity {
    private static final int RED = Color.rgb(233, 40, 50);
    private static final int RED_DARK = Color.rgb(216, 31, 41);
    private static final int NAVY = Color.rgb(6, 25, 54);
    private static final int MUTED = Color.rgb(98, 115, 145);
    private static final int BG = Color.rgb(248, 250, 253);
    private static final int REQ_PERMISSIONS = 72;
    private static final String ACTION_SMS_SENT = "com.example.emergencysos.SMS_SENT";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<EmergencyContact> contacts = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout root;
    private LinearLayout content;
    private int activeTab = 1;
    private long lastSosTap = 0L;
    private boolean alarmRunning = false;
    private boolean torchOn = false;
    private String cameraId;
    private ToneGenerator toneGenerator;
    private Runnable pendingSosSend;
    private boolean sendAfterPermissionGrant = false;
    private int smsPartsWaiting = 0;
    private int smsPartsSent = 0;
    private int smsPartsFailed = 0;
    private BroadcastReceiver smsSentReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("sos_app", MODE_PRIVATE);
        loadContacts();
        setupCamera();
        toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(Color.WHITE);
        registerSmsStatusReceiver();
        showShell();
        showSosPage();
    }

    @Override
    protected void onDestroy() {
        stopAlarm();
        if (smsSentReceiver != null) unregisterReceiver(smsSentReceiver);
        if (toneGenerator != null) toneGenerator.release();
        super.onDestroy();
    }

    private void showShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(28), dp(22), dp(28), dp(6));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(10), dp(8), dp(10), dp(8));
        nav.setBackgroundColor(Color.WHITE);
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(92)));

        nav.addView(navItem("Contacts", "[+]", 0), new LinearLayout.LayoutParams(0, -1, 1));
        nav.addView(navItem("SOS", "!", 1), new LinearLayout.LayoutParams(0, -1, 1));
        nav.addView(navItem("Medical", "<3", 2), new LinearLayout.LayoutParams(0, -1, 1));
    }

    private LinearLayout navItem(String label, String icon, int tab) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setOnClickListener(v -> {
            if (tab == 0) showContactsPage();
            if (tab == 1) showSosPage();
            if (tab == 2) showMedicalPage();
        });
        TextView i = text(icon, 25, activeTab == tab ? RED : MUTED, true);
        TextView l = text(label, 14, activeTab == tab ? RED : MUTED, true);
        item.addView(i);
        item.addView(l);
        return item;
    }

    private void rebuildShellFor(int tab) {
        activeTab = tab;
        showShell();
    }

    private void showSosPage() {
        rebuildShellFor(1);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.addView(text("E M E R G E N C Y   S O S", 14, RED, false));
        content.addView(text("Help is one tap away", 31, NAVY, true));
        TextView subtitle = text("Tap to alert contacts. Double-tap for siren & flash.", 16, MUTED, false);
        subtitle.setPadding(0, dp(8), 0, dp(28));
        content.addView(subtitle);

        TextView button = text("SOS", 56, Color.WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setBackground(circleDrawable(RED, RED_DARK));
        button.setElevation(dp(14));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(330), dp(330));
        bp.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(button, bp);
        button.setOnClickListener(v -> handleSosTap());

        TextView helper = text("Single tap -> send SMS + location\nDouble tap -> siren + screen flash", 16, MUTED, false);
        helper.setGravity(Gravity.CENTER);
        helper.setPadding(0, dp(28), 0, dp(28));
        content.addView(helper);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.setGravity(Gravity.CENTER);
        content.addView(cards, new LinearLayout.LayoutParams(-1, dp(94)));
        cards.addView(quickCard("Tel", "Contacts", "Manage list", () -> showContactsPage()), new LinearLayout.LayoutParams(0, -1, 1));
        Space gap = new Space(this);
        cards.addView(gap, new LinearLayout.LayoutParams(dp(14), -1));
        cards.addView(quickCard("Med", "Medical", "Vital info", () -> showMedicalPage()), new LinearLayout.LayoutParams(0, -1, 1));
    }

    private View quickCard(String icon, String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), 0, dp(12), 0);
        card.setBackground(roundDrawable(Color.WHITE, dp(18)));
        card.setElevation(dp(4));
        card.setOnClickListener(v -> action.run());
        TextView ic = text(icon, 27, RED, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(roundDrawable(Color.rgb(255, 237, 239), dp(13)));
        card.addView(ic, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(14), 0, 0, 0);
        copy.addView(text(title, 17, NAVY, true));
        copy.addView(text(subtitle, 14, MUTED, false));
        card.addView(copy);
        return card;
    }

    private void showContactsPage() {
        rebuildShellFor(0);
        content.setGravity(Gravity.NO_GRAVITY);
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.addView(text("E M E R G E N C Y", 14, RED, false));
        titleBox.addView(text("Contacts", 30, NAVY, true));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        Button add = primaryButton("+  Add");
        add.setOnClickListener(v -> showContactDialog(null, -1));
        header.addView(add, new LinearLayout.LayoutParams(dp(108), dp(54)));
        content.addView(header);
        Space s = new Space(this);
        content.addView(s, new LinearLayout.LayoutParams(1, dp(28)));

        if (contacts.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(10), dp(30), dp(10), dp(30));
            empty.setBackground(roundDrawable(Color.WHITE, dp(18)));
            empty.setElevation(dp(4));
            empty.addView(text("No list", 30, MUTED, false));
            empty.addView(text("No contacts yet", 21, NAVY, true));
            empty.addView(text("Add people who should be alerted in an emergency.", 16, MUTED, false));
            content.addView(empty, new LinearLayout.LayoutParams(-1, dp(205)));
            return;
        }

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        content.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        for (int i = 0; i < contacts.size(); i++) {
            list.addView(contactRow(contacts.get(i), i));
        }
    }

    private View contactRow(EmergencyContact contact, int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), dp(12), dp(12), dp(12));
        row.setBackground(roundDrawable(Color.WHITE, dp(16)));
        row.setElevation(dp(3));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(text(contact.name, 18, NAVY, true));
        copy.addView(text(contact.phone, 15, MUTED, false));
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        Button edit = iconButton("Edit");
        edit.setOnClickListener(v -> showContactDialog(contact, index));
        row.addView(edit);
        Button del = iconButton("Del");
        del.setOnClickListener(v -> confirmDelete(index));
        row.addView(del);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(84));
        rp.setMargins(0, 0, 0, dp(12));
        row.setLayoutParams(rp);
        return row;
    }

    private void showMedicalPage() {
        rebuildShellFor(2);
        content.setPadding(dp(24), dp(26), dp(24), 0);
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text("<3", 30, RED, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(roundDrawable(Color.rgb(255, 237, 239), dp(18)));
        header.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(14), 0, 0, 0);
        titleBox.addView(text("V I T A L   I N F O", 14, RED, false));
        titleBox.addView(text("Medical Profile", 30, NAVY, true));
        header.addView(titleBox);
        content.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(22), dp(18), dp(22));
        form.setBackground(roundDrawable(Color.WHITE, dp(18)));
        scroll.addView(form);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.setMargins(0, dp(24), 0, 0);
        content.addView(scroll, sp);

        EditText fullName = field(form, "Full name", "Full name", false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        form.addView(row, new LinearLayout.LayoutParams(-1, -2));
        EditText blood = field(row, "Blood type", "O+", false);
        EditText dob = field(row, "Date of birth", "dd-mm-yyyy", false);
        ((LinearLayout.LayoutParams) blood.getLayoutParams()).setMargins(0, 0, dp(10), dp(12));
        ((LinearLayout.LayoutParams) dob.getLayoutParams()).setMargins(dp(10), 0, 0, dp(12));
        EditText allergies = field(form, "Allergies", "Penicillin, peanuts...", true);
        EditText conditions = field(form, "Medical conditions", "Asthma, diabetes type 1...", true);
        EditText medications = field(form, "Current medications", "Insulin, Ventolin inhaler...", true);
        EditText notes = field(form, "Additional notes", "", true);

        fullName.setText(prefs.getString("fullName", ""));
        blood.setText(prefs.getString("blood", ""));
        dob.setText(prefs.getString("dob", ""));
        allergies.setText(prefs.getString("allergies", ""));
        conditions.setText(prefs.getString("conditions", ""));
        medications.setText(prefs.getString("medications", ""));
        notes.setText(prefs.getString("notes", ""));

        Button save = primaryButton("Save");
        save.setOnClickListener(v -> {
            prefs.edit()
                    .putString("fullName", fullName.getText().toString())
                    .putString("blood", blood.getText().toString())
                    .putString("dob", dob.getText().toString())
                    .putString("allergies", allergies.getText().toString())
                    .putString("conditions", conditions.getText().toString())
                    .putString("medications", medications.getText().toString())
                    .putString("notes", notes.getText().toString())
                    .apply();
            Toast.makeText(this, "Medical profile saved locally.", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams savep = new LinearLayout.LayoutParams(-1, dp(56));
        savep.setMargins(0, dp(8), 0, dp(16));
        form.addView(save, savep);
        TextView local = text("Stored locally on this device.", 14, MUTED, false);
        local.setGravity(Gravity.CENTER);
        form.addView(local);
    }

    private EditText field(LinearLayout parent, String label, String hint, boolean multiLine) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView l = text(label, 16, NAVY, true);
        EditText input = new EditText(this);
        input.setTextColor(NAVY);
        input.setHintTextColor(MUTED);
        input.setTextSize(16);
        input.setHint(hint);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(roundStrokeDrawable(Color.TRANSPARENT, dp(16), Color.rgb(218, 226, 237)));
        input.setSingleLine(!multiLine);
        input.setInputType(multiLine ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE : InputType.TYPE_CLASS_TEXT);
        if (multiLine) input.setGravity(Gravity.TOP | Gravity.START);
        box.addView(l);
        box.addView(input, new LinearLayout.LayoutParams(-1, multiLine ? dp(100) : dp(52)));
        LinearLayout.LayoutParams boxp = new LinearLayout.LayoutParams(0, -2, parent.getOrientation() == LinearLayout.HORIZONTAL ? 1 : 0);
        if (parent.getOrientation() != LinearLayout.HORIZONTAL) boxp = new LinearLayout.LayoutParams(-1, -2);
        boxp.setMargins(0, 0, 0, dp(16));
        parent.addView(box, boxp);
        return input;
    }

    private void handleSosTap() {
        long now = System.currentTimeMillis();
        if (now - lastSosTap < 420) {
            if (pendingSosSend != null) handler.removeCallbacks(pendingSosSend);
            lastSosTap = 0;
            toggleAlarm();
            return;
        }
        lastSosTap = now;
        pendingSosSend = () -> {
            if (System.currentTimeMillis() - lastSosTap >= 420) sendEmergencySms();
        };
        handler.postDelayed(pendingSosSend, 440);
    }

    private void sendEmergencySms() {
        if (contacts.isEmpty()) {
            Toast.makeText(this, "Add at least one emergency contact first.", Toast.LENGTH_LONG).show();
            showContactsPage();
            return;
        }
        if (!hasPermission(Manifest.permission.SEND_SMS) || !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            sendAfterPermissionGrant = true;
            requestPermissions(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CAMERA}, REQ_PERMISSIONS);
            return;
        }
        Toast.makeText(this, "Getting current location...", Toast.LENGTH_SHORT).show();
        getCurrentLocation(location -> sendEmergencySmsWithLocation(getLocationText(location)));
    }

    private void sendEmergencySmsWithLocation(String location) {
        String name = prefs.getString("fullName", "").trim();
        String message = "EMERGENCY SOS" + (name.isEmpty() ? "" : " from " + name) + ". I need help now. " + location;
        SmsManager smsManager = SmsManager.getDefault();
        smsPartsWaiting = 0;
        smsPartsSent = 0;
        smsPartsFailed = 0;
        for (EmergencyContact contact : contacts) {
            try {
                ArrayList<String> parts = smsManager.divideMessage(message);
                ArrayList<PendingIntent> sentIntents = new ArrayList<>();
                for (int i = 0; i < parts.size(); i++) {
                    Intent intent = new Intent(ACTION_SMS_SENT);
                    intent.setPackage(getPackageName());
                    intent.putExtra("contact", contact.name);
                    intent.putExtra("phone", contact.phone);
                    intent.putExtra("part", i + 1);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this,
                            (contact.phone + i + System.currentTimeMillis()).hashCode(),
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );
                    sentIntents.add(pendingIntent);
                }
                smsPartsWaiting += parts.size();
                smsManager.sendMultipartTextMessage(contact.phone, null, parts, sentIntents, null);
            } catch (Exception ex) {
                smsPartsFailed++;
                Toast.makeText(this, "SMS failed for " + contact.name + ": " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        if (smsPartsWaiting == 0) {
            Toast.makeText(this, "No SMS was queued. Check the phone number and SIM.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "SOS SMS queued. Waiting for phone network status...", Toast.LENGTH_LONG).show();
        }
    }

    private void registerSmsStatusReceiver() {
        smsSentReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (getResultCode() == RESULT_OK) smsPartsSent++;
                else smsPartsFailed++;

                int finished = smsPartsSent + smsPartsFailed;
                if (finished >= smsPartsWaiting && smsPartsWaiting > 0) {
                    String message = smsPartsFailed == 0
                            ? "SOS SMS sent successfully."
                            : "Some SMS messages failed. Sent parts: " + smsPartsSent + ", failed parts: " + smsPartsFailed + ". Check SIM, SMS balance, and phone numbers.";
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_SMS_SENT);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(smsSentReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(smsSentReceiver, filter);
        }
    }

    private void getCurrentLocation(LocationResult callback) {
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            callback.onLocationReady(null);
            return;
        }
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            String provider = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    ? LocationManager.GPS_PROVIDER
                    : LocationManager.NETWORK_PROVIDER;
            LocationListener listener = new LocationListener() {
                private boolean delivered = false;

                @Override
                public void onLocationChanged(Location location) {
                    if (delivered) return;
                    delivered = true;
                    lm.removeUpdates(this);
                    callback.onLocationReady(location);
                }
            };
            lm.requestLocationUpdates(provider, 0, 0, listener);
            handler.postDelayed(() -> {
                lm.removeUpdates(listener);
                callback.onLocationReady(getBestLastKnownLocation(lm));
            }, 8000);
        } catch (Exception ex) {
            callback.onLocationReady(null);
        }
    }

    private Location getBestLastKnownLocation(LocationManager lm) {
        try {
            Location best = null;
            for (String provider : lm.getProviders(true)) {
                Location loc = lm.getLastKnownLocation(provider);
                if (loc != null && (best == null || loc.getTime() > best.getTime())) {
                    best = loc;
                }
            }
            return best;
        } catch (Exception ex) {
            return null;
        }
    }

    private String getLocationText(Location location) {
        if (location == null) return "Live location was not available. Please call me immediately.";
        return "Location: https://maps.google.com/?q=" + location.getLatitude() + "," + location.getLongitude();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMISSIONS || !sendAfterPermissionGrant) return;
        sendAfterPermissionGrant = false;
        if (hasPermission(Manifest.permission.SEND_SMS) && hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            sendEmergencySms();
        } else {
            Toast.makeText(this, "SMS and location permissions are needed for SOS.", Toast.LENGTH_LONG).show();
        }
    }

    private void toggleAlarm() {
        if (alarmRunning) {
            stopAlarm();
            Toast.makeText(this, "Siren and flash stopped.", Toast.LENGTH_SHORT).show();
        } else {
            if (!hasPermission(Manifest.permission.CAMERA)) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERMISSIONS);
            alarmRunning = true;
            runAlarmPulse();
            Toast.makeText(this, "Siren and flash started. Double tap SOS again to stop.", Toast.LENGTH_LONG).show();
        }
    }

    private void runAlarmPulse() {
        if (!alarmRunning) return;
        toneGenerator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 300);
        vibrate();
        setTorch(!torchOn);
        content.setBackgroundColor(torchOn ? Color.rgb(255, 232, 235) : BG);
        handler.postDelayed(this::runAlarmPulse, 420);
    }

    private void stopAlarm() {
        alarmRunning = false;
        setTorch(false);
        if (content != null) content.setBackgroundColor(BG);
    }

    private void setupCamera() {
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            for (String id : manager.getCameraIdList()) {
                Boolean flash = manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    cameraId = id;
                    return;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void setTorch(boolean on) {
        if (cameraId == null || !hasPermission(Manifest.permission.CAMERA)) return;
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            manager.setTorchMode(cameraId, on);
            torchOn = on;
        } catch (CameraAccessException ignored) {
        }
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null) return;
        if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(180);
    }

    private void showContactDialog(EmergencyContact current, int index) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), 0);
        EditText name = dialogField("Name");
        EditText phone = dialogField("Phone number");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        if (current != null) {
            name.setText(current.name);
            phone.setText(current.phone);
        }
        form.addView(name);
        form.addView(phone);
        new AlertDialog.Builder(this)
                .setTitle(current == null ? "Add emergency contact" : "Edit emergency contact")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String n = name.getText().toString().trim();
                    String p = phone.getText().toString().trim();
                    if (n.isEmpty() || p.isEmpty()) {
                        Toast.makeText(this, "Name and phone number are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    EmergencyContact c = new EmergencyContact(n, p);
                    if (index >= 0) contacts.set(index, c);
                    else contacts.add(c);
                    saveContacts();
                    showContactsPage();
                })
                .show();
    }

    private EditText dialogField(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(16);
        return input;
    }

    private void confirmDelete(int index) {
        new AlertDialog.Builder(this)
                .setTitle("Delete contact?")
                .setMessage("This person will no longer receive SOS messages.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    contacts.remove(index);
                    saveContacts();
                    showContactsPage();
                })
                .show();
    }

    private void loadContacts() {
        contacts.clear();
        try {
            JSONArray array = new JSONArray(prefs.getString("contacts", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                contacts.add(new EmergencyContact(obj.getString("name"), obj.getString("phone")));
            }
        } catch (JSONException ignored) {
        }
    }

    private void saveContacts() {
        JSONArray array = new JSONArray();
        for (EmergencyContact c : contacts) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("name", c.name);
                obj.put("phone", c.phone);
                array.put(obj);
            } catch (JSONException ignored) {
            }
        }
        prefs.edit().putString("contacts", array.toString()).apply();
    }

    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundDrawable(RED, dp(24)));
        return b;
    }

    private Button iconButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(RED);
        b.setAllCaps(false);
        b.setBackground(roundStrokeDrawable(Color.TRANSPARENT, dp(12), Color.rgb(255, 207, 212)));
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private android.graphics.drawable.Drawable circleDrawable(int start, int end) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{start, end});
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        return d;
    }

    private android.graphics.drawable.Drawable roundDrawable(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private android.graphics.drawable.Drawable roundStrokeDrawable(int color, int radius, int stroke) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static final class EmergencyContact {
        final String name;
        final String phone;

        EmergencyContact(String name, String phone) {
            this.name = name;
            this.phone = phone;
        }
    }

    private interface LocationResult {
        void onLocationReady(Location location);
    }
}
