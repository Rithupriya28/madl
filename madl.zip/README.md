# Emergency SOS Android App

This is a native Android Studio starter project for an emergency SOS mobile app.

## Features

- Big red SOS button on the home screen.
- Single tap sends an emergency SMS to every saved emergency contact.
- SMS includes a Google Maps location link when a recent device location is available.
- Double tap starts or stops an alarm mode with siren tone, vibration, screen flash color, and flashlight when the device supports it.
- Contacts page supports adding, editing, deleting, and storing any number of emergency contacts.
- Medical page stores important local medical profile details such as blood type, allergies, conditions, medications, and notes.

## Open In Android Studio

1. Open Android Studio.
2. Choose **Open**.
3. Select this folder: `C:\Users\23190\OneDrive\ドキュメント\New project`.
4. Let Gradle sync.
5. Run the `app` configuration on a real Android phone.

SMS, flashlight, and accurate location are best tested on a physical Android device. Emulators often cannot send real SMS or use a real torch.

## Permissions Used

- `SEND_SMS` to send emergency text messages.
- `ACCESS_FINE_LOCATION` and `ACCESS_COARSE_LOCATION` to include location.
- `CAMERA` to control the flashlight.
- `VIBRATE` for alarm feedback.
